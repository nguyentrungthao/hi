/*
 * Copyright (c) 2010-2012 Sonatype, Inc. All rights reserved.
 *
 * This program is licensed to you under the Apache License Version 2.0,
 * and you may not use this file except in compliance with the Apache License Version 2.0.
 * You may obtain a copy of the Apache License Version 2.0 at http://www.apache.org/licenses/LICENSE-2.0.
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the Apache License Version 2.0 is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Apache License Version 2.0 for the specific language governing permissions and limitations there under.
 */
package org.asynchttpclient.handler;

import org.asynchttpclient.AsyncHandler;
import org.asynchttpclient.Request;

import java.io.File;
import java.io.FileInputStream;

/**
 * An extended {@link AsyncHandler} with two extra callback who get invoked during the content upload to a remote server.
 * This {@link AsyncHandler} must be used only with PUT and POST request.
 */
public interface ProgressAsyncHandler<T> extends AsyncHandler<T> {

    /**
     * Invoked when the content (a {@link File}, {@link String} or {@link FileInputStream}) has been fully
     * written on the I/O socket.
     *
     * @return a {@link AsyncHandler.State} telling to CONTINUE or ABORT the current processing.
     */
    State onHeadersWritten();

    /**
     * Invoked when the content (a {@link File}, {@link String} or {@link FileInputStream}) has been fully
     * written on the I/O socket.
     *
     * @return a {@link AsyncHandler.State} telling to CONTINUE or ABORT the current processing.
     */
    State onContentWritten();

    /**
     * Invoked when the I/O operation associated with the {@link Request} body wasn't fully written in a single I/O write
     * operation. This method is never invoked if the write operation complete in a sinfle I/O write.
     *
     * @param amount  The amount of bytes to transfer.
     * @param current The amount of bytes transferred
     * @param total   The total number of bytes transferred
     * @return a {@link AsyncHandler.State} telling to CONTINUE or ABORT the current processing.
     */
    State onContentWriteProgress(long amount, long current, long total);
}
